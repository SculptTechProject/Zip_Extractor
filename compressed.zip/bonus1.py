text = input("Enter a title: ")

length = len(text)

print(f"The length of this title is: {length}")